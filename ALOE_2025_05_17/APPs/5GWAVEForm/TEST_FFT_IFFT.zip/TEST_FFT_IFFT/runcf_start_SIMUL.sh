./stop_runcf.sh
runcf -c hwplatform/platform.conf
