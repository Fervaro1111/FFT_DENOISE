cd ../../../
sudo make install

