sudo runcf -f
sudo pkill -9 runcf
sudo pkill -9 exec
sudo pkill -9 bridge
sudo pkill -9 stats
sudo pkill -9 frontend
sudo pkill -9 swload
sudo pkill -9 swman
sudo pkill -9 hwman
sudo pkill -9 statsman
sudo pkill -9 sync_master
sudo pkill -9 cmdman
sudo pkill -9 gnuplot
