make clean
make
rm /tmp/*
sudo make install
