cd ../../../
make clean
sudo make install

