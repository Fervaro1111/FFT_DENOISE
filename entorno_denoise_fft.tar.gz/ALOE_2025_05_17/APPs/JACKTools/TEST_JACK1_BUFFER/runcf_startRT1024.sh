#sudo ./stop_runcf.sh

#sudo ./jack_server_start.sh

#sudo 
sudo runcf -c hwplatform/platformJACK1024.conf
