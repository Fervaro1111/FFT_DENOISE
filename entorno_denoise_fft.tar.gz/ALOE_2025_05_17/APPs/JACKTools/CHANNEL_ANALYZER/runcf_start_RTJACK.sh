sudo ./stop_runcf.sh

sudo ./jack_server_start.sh

sudo runcf -c hwplatform/platformJACK.conf
