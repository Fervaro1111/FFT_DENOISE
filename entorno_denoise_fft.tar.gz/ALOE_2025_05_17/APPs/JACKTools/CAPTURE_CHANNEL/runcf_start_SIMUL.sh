./stop_runcf.sh

./jack_server_start.sh

runcf -c hwplatform/platform.conf
