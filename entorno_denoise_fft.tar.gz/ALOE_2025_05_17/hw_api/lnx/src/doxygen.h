/** 
 * @mainpage ALOE Hardware API Implementation Documentation
 *
 * This documentation covers the ALOE HW API LINUX implementation details.
 *
 * Go back to http://epsc-gcr-002.upc.es/flexlab/wiki/DeveloperGuide
 *
 */
 