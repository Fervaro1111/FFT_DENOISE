
int sndcard_readcfg(char *filename, int *NsamplesIn, int *NsamplesOut);

int sndcard_init(int *timeSlot, float *rxBuffer, float *txBuffer, void (*sync)(void));

void sndcard_close();





