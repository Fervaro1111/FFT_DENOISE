#sudo ./configure LIBS='-lpthread -lboost_system'
make clean
sudo make install

