sudo pkill -9 runcf
sudo pkill -9 gnuplot
//make clean
sudo make install
runcf -f
runcf -f
runcf -c hw_api/lnx/cfg/platformNONE.conf
